# Master version for Pillow
__version__ = "8.4.0"
